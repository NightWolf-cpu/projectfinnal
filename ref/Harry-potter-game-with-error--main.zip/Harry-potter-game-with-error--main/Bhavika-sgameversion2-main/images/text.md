QUESTIONS FOR THE MAZE ...


q1 - What is the key ingredient in Polyjuice potion  ?
option1 - tincture of demiguise 
option2 - lacewing flies 
option3 - pearl dust 
 right option - option2 

 q2 - What is the key ingredient in Amortentia (love potion) ?
 option1 - pearl dust 
 option2 - knotgrass 
 option3 - shredded boomslang skin
 right option - option1

 q3 - Which row in prophecy hall has the prophecy about Harry and  Voldemort ?
 option1 - 87 
 option2 - 46
 option3 - 97
 right option - option3

 q4 - What was the name of Ginny's pet pygmy puff ?

option1 - Hedwig
 option2 - Arnold
 option3 - Crookshanks
 right option - option2

 q5 - What was the name of Ron's pet owl (personal) ?
 option1 - Errol 
 option2 - Hedwig 
 option3 - Pigwidgeon
 right option - option3

 q6 - Which Harry Potter character existed in real life ?
 option1 -Nicholas Flamel 
 option2 -  Glideroy Lockhart
 option3 - Pomona Sprout 
 right option - option1

 q7 - What was the hair colour of Teddy Lupin when he was born and they changed into which colour ?
 option1 -  black-ginger
 option2 - pink-blue
 option3 - blue-green 
 right option - option1

 q8 - What was the name of second Peverell bother , who owned the Resurrection Stone ?
 option1 - Antioch Peverell 
 option2 - Cadmus Peverell 
 option3 - Ignotus Peverell
 right option - option2

 q9 - Where do Harry and Ginny have their first kiss ?
 option1 - Common room
 option2 - Room of Requirement
 option3 - Quidditch pitch
 right option - option1


q10 - Who tried to slip Harry into a love potion ?
option1 - Cho Chang  
 option2 - Hermione Granger
 option3 - Romilda Vane 
 right option - option3

 q11 - What is the  name of plant that Neville got from his grandmother on his birthday .
 option1 - Mimbulus Mimbletonia 
 option2 - Devil's Snare
 option3 - Gillyweed
 right option - option1

QUESTIONS FOR SORTING .....

q1 - What your friends describe you as ?
 
 op1 - brave (4)
op2 - funny(3)
op3 - kind (2)
op4 - cunning(1)

q2 - Choose your favourite potion 

op1 - Felix feliciis (4)
op2 - Polyjuice potion(1)
op3 - Amortentia (3)
op4 - Veritaserum(2)

q3 - Choose a place to hangout 

op1 -Three broomsticks (4)
op2 - Leaky cauldron(2)
op3 - Common room(1)
op4 - Diagon Alley(3)

FOR RESULTS ....

if 3-4-5
House - Slytherin

if 5-6-7
House - Hufflepuff

if 8-9-10
House - Gryffindor 

if 11-12-13
House - Ravenclaw